import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
// import PlanetsContext from './core/PlanetContext';

ReactDOM.render(
  <App />,
  document.getElementById('root'),
);
