const PlanetsContext = useContext([]);

export default PlanetsContext;
