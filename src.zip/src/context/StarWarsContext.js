import { createContext } from 'react';

const StarWarsContext = createContext();

export default StarWarsContext;
