import { createContext } from 'react';

const SWContext = createContext();

export default SWContext;
