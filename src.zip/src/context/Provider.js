import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import StarWarsContext from './StarWarsContext';
import getPlanets from '../services/index';

function Provider({ children }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({ filterByName: { name: '' } });

  async function importPlanets() {
    const planetsList = await getPlanets();
    setData(planetsList);
    setLoading(true);
  }

  useEffect(() => {
    importPlanets();
  }, []);

  function handleNameChange(e) {
    setFilters({ filterByName: { name: e.target.value } });
  }

  const globalState = {
    data,
    loading,
    filters,
    handleNameChange,
  };
  return (
    <StarWarsContext.Provider value={ globalState }>
      {children}
    </StarWarsContext.Provider>
  );
}

Provider.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Provider;
